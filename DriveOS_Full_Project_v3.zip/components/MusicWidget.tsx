import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, SkipForward, SkipBack } from 'lucide-react';

const MusicWidget = () => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [trackIndex, setTrackIndex] = useState(0);

  const handleDragEnd = (event: any, info: any) => {
    if (info.offset.x < -50) {
      setTrackIndex(prev => prev + 1);
    } else if (info.offset.x > 50) {
      setTrackIndex(prev => Math.max(0, prev - 1));
    }
  };

  return (
    <div className="h-full w-full bg-[#161B24]/80 backdrop-blur-xl border border-[#1E2A3A] rounded-[16px] p-6 flex flex-col justify-between shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <span className="text-[#1DB954] font-bold tracking-wider text-sm uppercase">Spotify</span>
        <span className="text-[#8A9BB0] text-sm">Bluetooth</span>
      </div>

      <motion.div 
        className="flex-1 w-full bg-[#0D0F14] rounded-xl flex items-center justify-center overflow-hidden cursor-grab active:cursor-grabbing relative"
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.2}
        onDragEnd={handleDragEnd}
        onDoubleClick={() => setIsPlaying(!isPlaying)}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-[#1E90FF]/20 to-transparent"></div>
        <span className="text-[#8A9BB0] font-['Rajdhani'] uppercase tracking-widest text-xs">Swipe to Change</span>
      </motion.div>

      <div className="mt-6">
        <h2 className="text-2xl font-bold font-['Rajdhani'] text-white truncate uppercase">Cyberpunk Drive</h2>
        <p className="text-[#8A9BB0] text-lg truncate">Synthwave Artist</p>
        
        <div className="w-full h-2 bg-[#0D0F14] rounded-full mt-4 overflow-hidden">
          <div className="h-full bg-[#1E90FF] w-[45%] shadow-[0_0_10px_#1E90FF]"></div>
        </div>

        <div className="flex justify-between items-center mt-6">
          <button className="p-3 text-[#8A9BB0] hover:text-white transition-colors">
            <SkipBack size={32} />
          </button>
          <button 
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-4 bg-[#1E90FF] rounded-full text-white shadow-[0_0_15px_rgba(30,144,255,0.4)]"
          >
            {isPlaying ? <Pause size={32} fill="currentColor" /> : <Play size={32} fill="currentColor" />}
          </button>
          <button className="p-3 text-[#8A9BB0] hover:text-white transition-colors">
            <SkipForward size={32} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default MusicWidget;