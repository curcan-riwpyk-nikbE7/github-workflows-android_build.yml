import React, { useState } from 'react';
import { Navigation, Music, Phone, Grid, Settings } from 'lucide-react';

const navItems = [
  { id: 'nav', icon: Navigation, color: '#1E90FF' },
  { id: 'music', icon: Music, color: '#FF4444' },
  { id: 'phone', icon: Phone, color: '#1DB954' },
  { id: 'apps', icon: Grid, color: '#FFFFFF' },
  { id: 'settings', icon: Settings, color: '#8A9BB0' },
];

const Sidebar = () => {
  const [active, setActive] = useState('nav');

  return (
    <aside className="w-28 bg-[#0D0F14] border-r border-[#1E2A3A] flex flex-col items-center py-6 gap-6 z-10">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = active === item.id;
        
        return (
          <button
            key={item.id}
            onClick={() => setActive(item.id)}
            className={`w-[70px] h-[70px] rounded-[16px] flex items-center justify-center transition-all duration-300 ${
              isActive 
                ? 'bg-[#161B24] border border-[#1E90FF]' 
                : 'bg-transparent border border-transparent hover:bg-[#161B24]/50'
            }`}
            style={{
              boxShadow: isActive ? '0 0 15px rgba(30, 144, 255, 0.4)' : 'none',
              color: isActive ? item.color : '#8A9BB0'
            }}
          >
            <Icon size={32} strokeWidth={isActive ? 2.5 : 2} />
          </button>
        );
      })}
    </aside>
  );
};

export default Sidebar;