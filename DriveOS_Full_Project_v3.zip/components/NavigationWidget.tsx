import React from 'react';
import { motion } from 'framer-motion';
import { useDriveStore } from '../store/useAppStore';
import { MapPin, CornerUpRight, Compass, Navigation } from 'lucide-react';

const NavigationWidget = () => {
  const { navigationApp } = useDriveStore();
  const colors = { Google: '#1E90FF', Yandex: '#FFCC00', '2GIS': '#1DB954' };
  const activeColor = colors[navigationApp] || '#FFFFFF';

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.2 }}
      className="h-full w-full bg-[#161B24]/80 backdrop-blur-xl border border-[#1E2A3A] rounded-[16px] p-6 flex flex-col relative shadow-lg overflow-hidden"
    >
      <div className="absolute inset-0 z-0 bg-[#0D0F14] opacity-70">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1e2a3a]/30 to-transparent" />
      </div>

      <div className="relative z-10 flex flex-col h-full justify-between">
        <div className="flex items-center gap-5 p-5 bg-[#0D0F14]/80 border border-[#1E2A3A] rounded-xl shadow-inner backdrop-blur-sm">
          <div className="w-16 h-16 rounded-xl flex items-center justify-center p-2" style={{ backgroundColor: `${activeColor}20` }}>
            <CornerUpRight size={48} stroke={activeColor} strokeWidth={2.5} />
          </div>
          <div>
            <span className="font-['Rajdhani'] font-bold text-6xl text-white">700</span>
            <span className="font-['Inter'] font-medium text-3xl text-[#8A9BB0] ml-1">ft</span>
            <h2 className="font-['Inter'] text-2xl font-semibold text-white mt-1 uppercase">Turn Right on Pine St.</h2>
          </div>
        </div>

        <div className="flex justify-between items-center bg-[#0D0F14]/50 p-4 rounded-xl border border-[#1E2A3A] backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <Compass size={24} className="text-[#8A9BB0]" />
            <span className="font-['Inter'] font-medium text-lg text-white">ETA 3:45 PM (12 mins)</span>
          </div>
          <button className="font-['Rajdhani'] flex items-center gap-2 px-5 py-3 bg-[#1E90FF] rounded-lg shadow-[0_0_15px_rgba(30,144,255,0.4)] text-white font-bold uppercase">
            <Navigation size={18} />
            Route
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default NavigationWidget;