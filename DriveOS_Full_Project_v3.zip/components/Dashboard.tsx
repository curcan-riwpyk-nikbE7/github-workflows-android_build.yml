import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDriveStore } from '../store/useAppStore';
import Sidebar from './Sidebar';
import SystemBar from './SystemBar';
import NavigationWidget from './NavigationWidget';
import MusicWidget from './MusicWidget';

const Dashboard = () => {
  const { activeLayout } = useDriveStore();

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0D0F14] text-white font-['Inter'] overflow-hidden select-none">
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        
        <main className="flex-1 p-6 relative">
          <AnimatePresence mode="popLayout">
            {activeLayout === 'Classic' && (
              <motion.div 
                key="classic"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4, type: 'spring' }}
                className="grid grid-cols-4 grid-rows-2 gap-6 h-full"
              >
                <div className="col-span-2 row-span-2">
                  <NavigationWidget />
                </div>
                <div className="col-span-1 row-span-2">
                  <MusicWidget />
                </div>
                <div className="col-span-1 row-span-1 bg-[#161B24]/80 backdrop-blur-xl border border-[#1E2A3A] rounded-[16px] p-4">
                  <h3 className="font-['Rajdhani'] font-bold text-[#8A9BB0]">OBD TELEMETRY</h3>
                  <div className="mt-4 flex flex-col gap-2">
                    <div className="flex justify-between font-tech text-xl">
                      <span>RPM</span>
                      <span className="text-drive-blue">2150</span>
                    </div>
                    <div className="flex justify-between font-tech text-xl">
                      <span>TEMP</span>
                      <span className="text-drive-red">195°F</span>
                    </div>
                  </div>
                </div>
                <div className="col-span-1 row-span-1 bg-[#161B24]/80 backdrop-blur-xl border border-[#1E2A3A] rounded-[16px] p-4">
                  <h3 className="font-['Rajdhani'] font-bold text-[#8A9BB0]">TIRE PRESSURE</h3>
                   <div className="grid grid-cols-2 gap-2 mt-2 font-tech">
                      <div className="text-green-400">FL: 34</div>
                      <div className="text-green-400">FR: 34</div>
                      <div className="text-green-400">RL: 35</div>
                      <div className="text-green-400">RR: 35</div>
                   </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>
      <SystemBar />
    </div>
  );
};

export default Dashboard;