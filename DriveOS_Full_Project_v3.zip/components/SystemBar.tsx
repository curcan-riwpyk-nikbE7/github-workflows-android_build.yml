import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Home, ArrowLeft, Volume2, Sun, LayoutGrid, Power, X } from 'lucide-react';

const SystemBar = () => {
  const [showVolume, setShowVolume] = useState(false);
  const [showBrightness, setShowBrightness] = useState(false);

  return (
    <footer className="h-24 bg-[#0D0F14] border-t border-[#1E2A3A] flex items-center justify-between px-10 gap-6 z-20 relative">
      <div className="flex items-center gap-6">
        {[Home, ArrowLeft, Volume2, Sun].map((Icon, idx) => (
          <button 
            key={idx}
            onClick={() => idx === 2 ? setShowVolume(!showVolume) : idx === 3 ? setShowBrightness(!showBrightness) : null}
            className="w-[70px] h-[70px] rounded-[16px] bg-[#161B24] border border-[#1E2A3A] flex items-center justify-center text-white"
          >
            <Icon size={32} />
          </button>
        ))}
      </div>
      <div className="flex gap-6">
          <button className="w-[70px] h-[70px] rounded-[16px] bg-[#161B24] border border-[#1E2A3A] flex items-center justify-center text-[#1E90FF] shadow-[0_0_15px_rgba(30,144,255,0.3)]">
            <LayoutGrid size={32} />
          </button>
          <button className="w-[70px] h-[70px] rounded-[16px] bg-[#161B24] border border-[#1E2A3A] flex items-center justify-center text-[#FF4444]">
            <Power size={32} />
          </button>
      </div>
    </footer>
  );
};

export default SystemBar;