import { create } from 'zustand';

type LayoutMode = 'Classic' | 'NavFocus' | 'MusicFocus' | 'Minimalist';
type NavEngine = 'Yandex' | '2GIS' | 'Google';

interface DriveStore {
  activeLayout: LayoutMode;
  navigationApp: NavEngine;
  isDark: boolean | 'Auto';
  unitSystem: 'Metric' | 'Imperial';
  mockOBD: { rpm: number; temp: number; speed: number };
  
  setActiveLayout: (layout: LayoutMode) => void;
  setNavigationApp: (app: NavEngine) => void;
}

export const useDriveStore = create<DriveStore>((set) => ({
  activeLayout: 'Classic',
  navigationApp: 'Yandex',
  isDark: true,
  unitSystem: 'Metric',
  mockOBD: { rpm: 2150, temp: 195, speed: 65 },
  
  setActiveLayout: (layout) => set({ activeLayout: layout }),
  setNavigationApp: (app) => set({ navigationApp: app }),
}));